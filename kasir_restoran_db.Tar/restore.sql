--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.userr DROP CONSTRAINT userr_pkey;
ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY public.masakan DROP CONSTRAINT masakan_pkey;
ALTER TABLE ONLY public.levell DROP CONSTRAINT levell_pkey;
ALTER TABLE ONLY public.detail_order DROP CONSTRAINT detail_order_pkey;
DROP TABLE public.userr;
DROP TABLE public.transaksi;
DROP TABLE public.orderr;
DROP TABLE public.masakan;
DROP TABLE public.levell;
DROP TABLE public.detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order integer NOT NULL,
    id_order character varying(10),
    id_masakan character varying(4),
    keterangan character varying(225),
    status_detail_order character varying(20)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: levell; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE levell (
    id_level integer NOT NULL,
    nama_level character varying(30)
);


ALTER TABLE levell OWNER TO postgres;

--
-- Name: masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE masakan (
    id_masakan integer NOT NULL,
    nama_masakan character varying(30),
    harga integer,
    status_masakan character varying(30)
);


ALTER TABLE masakan OWNER TO postgres;

--
-- Name: orderr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orderr (
    id_order character varying(10),
    no_meja integer,
    tanggal date,
    id_user integer,
    keterangan character varying(225),
    status_order character varying(20)
);


ALTER TABLE orderr OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi integer NOT NULL,
    id_user character varying(10),
    id_order character varying(10),
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Name: userr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE userr (
    id_user integer NOT NULL,
    username character varying(30),
    passwordd character varying(30),
    nama_user character varying(30),
    id_level integer
);


ALTER TABLE userr OWNER TO postgres;

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, keterangan, status_detail_order) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: levell; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY levell (id_level, nama_level) FROM stdin;
\.
COPY levell (id_level, nama_level) FROM '$$PATH$$/2822.dat';

--
-- Data for Name: masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2824.dat';

--
-- Data for Name: orderr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2821.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: userr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY userr (id_user, username, passwordd, nama_user, id_level) FROM stdin;
\.
COPY userr (id_user, username, passwordd, nama_user, id_level) FROM '$$PATH$$/2820.dat';

--
-- Name: detail_order detail_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_order
    ADD CONSTRAINT detail_order_pkey PRIMARY KEY (id_detail_order);


--
-- Name: levell levell_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY levell
    ADD CONSTRAINT levell_pkey PRIMARY KEY (id_level);


--
-- Name: masakan masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY masakan
    ADD CONSTRAINT masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: userr userr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY userr
    ADD CONSTRAINT userr_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

